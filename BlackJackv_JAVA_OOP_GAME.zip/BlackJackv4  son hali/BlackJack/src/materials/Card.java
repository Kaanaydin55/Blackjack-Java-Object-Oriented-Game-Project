package materials;

public class Card {


	public static final int ACE = 1;
	public static final int ACE_SECOND = 11;
	public static final int JACK = 11;
	public static final int QUEEN = 12;
	public static final int KING = 13;
	public static final int CARD_COUNT_PER_GROUP = 13; 
	
	private CardGroup group;
	private int value;
	
	public Card(CardGroup group, int value){
		this.group = group;
		this.value = value;
	}
	public CardGroup getGroup() {
		return group;
	}
	public void setGroup(CardGroup group) {
		this.group = group;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public boolean isAce() {
		return value == 1;
	}
	public int getWorthValue() {
		return Math.min(10, value);
	}
	public int getSecondWorthValue() {
		if (value == ACE)
			return ACE_SECOND;
		return getWorthValue();
	}
	public CardColor getColor() {
		if(group == CardGroup.HEART || group == CardGroup.DIAMOND)
			return CardColor.RED;
		return CardColor.BLACK;		
	}
	@Override
	public String toString() {
		return "Card [group=" + group + ", value=" + value + "]";
	}
	public String imageName() {
		String imageName = "";
		if(group == CardGroup.DIAMOND)
			imageName += "l";
		else if(group == CardGroup.CLUB)
			imageName += "k";
		else if(group == CardGroup.HEART)
			imageName += "s";
		else if(group == CardGroup.SPADE)
			imageName += "p";
		else
			System.out.println("Card Group Error");
		if(value > 1 && value < JACK)
			imageName += value;
		else if(value == ACE)
			imageName += "a";
		else if(value == JACK)
			imageName += "j";
		else if(value == QUEEN)
			imageName += "q";
		else if(value == KING)
			imageName += "k";
		else {
			System.out.println(this);
			System.out.println("Card Value Error");
		}
			
		return imageName;
	}
}
