package actors;

import java.util.ArrayList;

import game.Game;
import materials.*;

public class Dealer extends Actor{
	
	ArrayList<Card> cards;
	public Dealer(Game game, String firstname, String lastname) {
		super(game, firstname, lastname);
		cards = new ArrayList<Card>();
		for(CardGroup cg : CardGroup.values()) {
			for(int j = 0; j < Card.CARD_COUNT_PER_GROUP; j++)
				cards.add(new Card(cg, j + 1));
		}
	}
	public Card giveACard() {
		return cards.remove(0);
	}
	public ArrayList<Card> getCards() {
		return cards;
	}
	public void setCards(ArrayList<Card> cards) {
		this.cards = cards;
	}
	public int getCardCount() {
		return cards.size();
	}

}
