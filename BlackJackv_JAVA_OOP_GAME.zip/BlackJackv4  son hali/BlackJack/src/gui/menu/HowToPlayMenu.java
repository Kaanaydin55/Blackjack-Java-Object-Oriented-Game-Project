package gui.menu;

import java.awt.Font;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import gui.MainFrame;

public class HowToPlayMenu extends JPanel{
	JTextArea instructions;
	MainFrame mainFrame;
	public static String context = "The aim of the game is not to exceed 21.\n"
			+ "To reach the closest number to 21. If you reach 21, you win automatically. \n"
			+ "If you pass 21, you automatically lose and the turn passes to the other player. \n "
			+ "Some rules of the game are considered 10 even if the values of ace, jack, queen, king are more than 10. \n"
			+ "Also, the value of ACE is counted as 1 if your deck exceeds 15, depending on the situation. \n"
			+ "The dealer shuffles the ranked cards in his hand without being involved in the game. \n"
			+ " Distributes it to users. \n"
			+ " Users can stop wherever they want without taking risks or try not to exceed 21 by taking risks. \n";

	public HowToPlayMenu(MainFrame mainFrame) {
		super();
		this.mainFrame = mainFrame;
		instructions =  new JTextArea(context);
		add(instructions);
	}
	
}
