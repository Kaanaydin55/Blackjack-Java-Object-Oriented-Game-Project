package gui.game.user;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import actors.Dealer;
import gui.game.GamePanel;

public class DealerPanel extends UserPanel{
	private JLabel cardCountLabel;
	public DealerPanel(GamePanel gamePanel, Dealer dealer){
		super(gamePanel, dealer);
		nameLabel.setForeground(Color.RED);
		cardCountLabel = new JLabel("Card Count: " + ((Dealer)actor).getCardCount());
		
		gbc.gridy = 1;
		add(cardCountLabel, gbc);
		
		ImageIcon ic = new ImageIcon(System.getProperty("user.dir") + "\\img\\deck.jpg");
		JLabel cardIcon = new JLabel(ic);
		
		gbc.gridx = 2;
		add(cardIcon, gbc);
		//gamePanel.getMainFrame().pack();
	}
	@Override
	public void update() {
		cardCountLabel.setText("Card Count: " + ((Dealer)actor).getCardCount());
	}
	public JLabel getCardCountLabel() {
		return cardCountLabel;
	}
	public void setCardCountLabel(JLabel cardCountLabel) {
		this.cardCountLabel = cardCountLabel;
	}
	
}
