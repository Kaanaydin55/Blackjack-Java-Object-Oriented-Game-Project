package gui.game;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import actors.Dealer;
import actors.Player;
import game.Game;
import game.GameStatus;
import gui.MainFrame;
import gui.game.subpanel.HandPanel;
import gui.game.subpanel.UsersContainer;
import gui.game.user.DealerPanel;
import gui.game.user.PlayerPanel;

public class GamePanel extends JPanel {
	MainFrame mainFrame;
	UsersContainer usersContainer;
	HandPanel handPanel;
	Game game;
	JButton drawACard;
	JButton passTurn;
	JButton addNewPlayer;
	JButton removePlayer;
	
	public GamePanel(MainFrame mainFrame) {
		this.mainFrame = mainFrame;
		
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		game = new Game();
		
		JButton goBack = new JButton("Go Back");
		goBack.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mainFrame.getLayout().show(mainFrame.getCards(), MainFrame.mainMenuCard);
			}
		});
		goBack.setAlignmentX(CENTER_ALIGNMENT);
		add(goBack);
		usersContainer = new UsersContainer(this,
											new DealerPanel(this, (Dealer)game.getActors()[0]),
											new PlayerPanel[] {	new PlayerPanel(this, (Player)game.getActors()[1]), 
																new PlayerPanel(this, (Player)game.getActors()[2]) } );
		
		add(usersContainer);
		
		usersContainer.getPlayerPanels()[0].getNameLabel().setForeground(Color.BLUE);
		handPanel = new HandPanel(this);
		add(handPanel);
		
		drawACard = new JButton("Draw a card");
		passTurn = new JButton("Pass Turn");
		
		drawACard.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e){
				if(game.getStatus() == GameStatus.READY) {
					game.setStatus(GameStatus.PLAYING);
				}
				
				((Player)(game.getActors()[game.getTurn()])).drawACard();
				usersContainer.getDealerPanel().update();
				usersContainer.getPlayerPanels()[game.getTurn() - 1].update();
				
				if(((Player)(game.getActors()[game.getTurn()])).lost()) {
					goNextPlayer();
				}
				handPanel.update();
			}
			
		});
		drawACard.setAlignmentX(CENTER_ALIGNMENT);
		add(drawACard);
		
		
		passTurn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(game.getStatus() == GameStatus.READY)
					game.setStatus(GameStatus.PLAYING);
				goNextPlayer();
			}
		});
		passTurn.setAlignmentX(CENTER_ALIGNMENT);
		add(passTurn);
		
		addNewPlayer = new JButton("Add New Player");
		addNewPlayer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(game.getStatus() != GameStatus.READY) {
					JOptionPane.showMessageDialog(mainFrame, "Not possible after start.");
					return;
				}
				
				String fullname = JOptionPane.showInputDialog(mainFrame, "Please enter full name?", "New" + " Player");
				String[] name = fullname.split(" ");
				if(name.length != 2) {
					JOptionPane.showMessageDialog(mainFrame, "Illegal name(Only a name + a surname allowed)");
					return;
				}
				Player player = new Player(game, name[0], name[1]);
				game.addPlayer(player);
				usersContainer.addNewPlayer(player);
			}
		});
		
		addNewPlayer.setAlignmentX(CENTER_ALIGNMENT);
		add(addNewPlayer);
		
		removePlayer = new JButton("Remove Player");
		removePlayer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(game.getStatus() != GameStatus.READY) {
					JOptionPane.showMessageDialog(mainFrame, "Not possible after start.");
					return;
				}
				game.removePlayer();
				usersContainer.removePlayer();
			}
		});
		removePlayer.setAlignmentX(CENTER_ALIGNMENT);
		add(removePlayer);
	}

	public MainFrame getMainFrame() {
		return mainFrame;
	}

	public void setMainFrame(MainFrame mainFrame) {
		this.mainFrame = mainFrame;
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}
	public void finishGame() {
		game.setStatus(GameStatus.FINISHED);
		drawACard.setEnabled(false);
		passTurn.setEnabled(false);
		PlayerPanel[] playerPanels = usersContainer.getPlayerPanels();
		PlayerPanel winningPanel = playerPanels[0];
		for(PlayerPanel panel : playerPanels) {
			if(((Player)(panel.getActor())).getScore() > ((Player)(winningPanel.getActor())).getScore()) {
				winningPanel = panel;
			}
		}
		if(!((Player)(winningPanel.getActor())).lost()) {
			winningPanel.getNameLabel().setForeground(Color.GREEN);
			winningPanel.getStatusLabel().setText("WON !!!");
		}
	}
	public void goNextPlayer() {
		usersContainer.getPlayerPanels()[game.getTurn() - 1].getNameLabel().setForeground(Color.BLACK);
		if(game.getTurn() == game.getPlayers().length) {
			finishGame();
			return;
		}
		game.setTurn(game.getTurn() + 1);
		usersContainer.getPlayerPanels()[game.getTurn() - 1].getNameLabel().setForeground(Color.BLUE);
	}

	public UsersContainer getUsersContainer() {
		return usersContainer;
	}

	public void setUsersContainer(UsersContainer usersContainer) {
		this.usersContainer = usersContainer;
	}

	public HandPanel getHandPanel() {
		return handPanel;
	}

	public void setHandPanel(HandPanel handPanel) {
		this.handPanel = handPanel;
	}
	
}
