package game;

public enum GameStatus {
	READY, PLAYING, FINISHED
}