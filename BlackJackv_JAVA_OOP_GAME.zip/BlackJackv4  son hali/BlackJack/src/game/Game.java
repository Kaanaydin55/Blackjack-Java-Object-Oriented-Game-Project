package game;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import actors.Actor;
import actors.Dealer;
import actors.Player;
import materials.Card;

public class Game {
	public static final int MAX_SCORE_PER_TURN = 21;

	Actor[] actors;
	int numberOfRounds;
	int roundCount;
	GameStatus status;
	int turn;
	public Game(){	
		numberOfRounds = 10;
		actors = new Actor[3];
		actors[0] = new Dealer(this, "Dealer", " ");
		actors[1] = new Player(this, "Kaan", "Aydın");
		actors[2] = new Player(this, "Ulas", "Korkmaz");
		status = GameStatus.READY;
		turn = 1;
		shuffle();
	}
	public void shuffle() {
		
		Dealer dealer = (Dealer)actors[0]; 
		Collections.shuffle(dealer.getCards());
	}
	public Dealer getDealer() {
		return (Dealer)actors[0];
	}
	public Actor[] getActors() {
		return actors;
	}
	public Actor[] getPlayers() { 
		return (Arrays.copyOfRange(actors, 1, actors.length));
	}
	public void setActors(Actor[] actors) {
		this.actors = actors;
	}
	public int getRoundCount() {
		return roundCount;
	}
	public void setRoundCount(int roundCount) {
		this.roundCount = roundCount;
	}
	public GameStatus getStatus() {
		return status;
	}
	public void setStatus(GameStatus status) {
		if(status == GameStatus.FINISHED)
			System.out.println("Game Over");
		this.status = status;
	}
	public int getTurn() {
		return turn;
	}
	public void setTurn(int turn) {
		this.turn = turn;
	}
	public int getNumberOfRounds() {
		return numberOfRounds;
	}
	public void removePlayer() {
		if(actors.length <= 1)
			return;
		Actor[] newActors = new Actor[actors.length - 1];
		for(int i = 0; i < actors.length - 1; i++)
			newActors[i] = actors[i];
		actors = newActors;
	}
	public void addPlayer(Player player) {
		Actor[] newActors = new Actor[actors.length + 1];
		for(int i = 0; i < actors.length; i++)
			newActors[i] = actors[i];
		newActors[newActors.length - 1] = player;
		actors = newActors;
	}
}
